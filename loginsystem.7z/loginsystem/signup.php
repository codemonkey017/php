<?php



if(isset($_POST['signup__Submit'])){

    require "database.php";
    
    $username = $_POST['userName'];
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    $pwdConfirm = $_POST['pwdConfirm'];

    if (empty($username) || empty($email) || empty($pwd) || empty($pwdConfirm)) {
        header("Location: ../signup.php?error=emptyfields&uid=".$username."&mail=".$email);
        exit();
    } 
    else if (!filter_var($email, FILTER_VALIDATE_EMAIL) && (!preg_match("/^[a-zA-z0-9*$/]", $username))  ) {
        header("Location: ../signup.php?error=invalidmailuid");
        exit();
    }
    else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../signup.php?error=invalidmail&uid=".$username);
        exit();
    }
    else if (!preg_match("/^[a-zA-z0-9]*$/", $username)) {
        header("Location: ../signup.php?error=invaliduid&mail=".$email);
        exit();
    }
    else if ($pwd !== $pwdConfirm ) {
        header("Location: ../signup.php?error=passwordcheck&uid=".$username. "&mail=".$email);
    }

    else {
        //create a template
        $sql = "SELECT * FROM users WHERE usersName = ? OR usersEmail = ?;";
        //create a preapred statement/returns an object to use with stmt_prepare 
        $stmt = mysqli_stmt_init($conn);
        //prepare the prepared statement
        //run function to test failure or success
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("Location: ../signup.php?error=sqlerror");
            exit();
        }
       
        else {
            //bind parameters we want to replace in the template's placeholder  
            mysqli_stmt_bind_param($stmt, "ss", $username, $email);
            //run parameters inside database 
            mysqli_stmt_execute($stmt);
            //store the result we got back from database inside variable $stmt
            mysqli_stmt_store_result($stmt);
            //return the result of the database in rows
            //if there is a match, it will be 1 or more 
            $resultCheck =  mysqli_stmt_num_rows($stmt);
            if($resultCheck > 0) {
             header("Location: ../signup.php?error=usertaken&mail=".$email);
             exit();
            }
            else {

                $sql = "INSERT INTO users (usersName, usersEmail, usersPwd) VALUES (?, ?, ?)";
                //create a prepare statement
                $stmt = mysqli_stmt_init($conn);
               //prepare the prepared statement
              //run function to test failure or success
                if(!mysqli_stmt_prepare($stmt, $sql)){
                    header("Location: ../signup.php?error=sqlerror");
                    exit();
            }
            else {

                $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
                mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hashedPwd);
                mysqli_stmt_execute($stmt);
                header("Location: ../signup.php?signup=success");
        

            }
         }
         

         

         
    }
}

mysqli_stmt_close($stmt);
mysqli_close($conn);




}
else {
    header("Location: ../signup.php");

}











// if(isset($_POST["signup__Submit"])){
//     echo "not illegal";
    
//     require_once "database.php";

// $userName = $_POST["userName"]; 
// $email = $_POST["email"]; 
// $pwd = $_POST["pwd"]; 
// $pwdConfirm = $_POST["pwdConfirm"]; 


 
// }

// if(emptyInputSignup($userName, $email, $pwd, $pwdConfirm) !== false){
// header("Location: ../signup.php?error=emptyinput");
// exit();
// }

// if(invalidUsername($userName) !== false){
// header("Location: ../signup.php?error=invalidusername");
// exit();
// }
// if(invalidEmail($email) !== false){
// header("Location: ../signup.php?error=invalidemail");
// exit();
// }
// if(pwdMatch($pwd, $pwdConfirm) !== false){
// header("Location: ../signup.php?error=passworddontmatch");
// exit();
// }

// if(usernameExists($conn, $userName, $email) !== false){
// header("Location: ../signup.php?error=usernametaken");
// exit();
// }


// else {
//     echo  "illegal";
// }




// function emptyInputSignup($userName, $email, $pwd, $pwdConfirm ){
//     if(empty($userName) || empty($email) || empty($pwd) || empty($pwdConfirm)){
//         $result = true; 
//         } 
//         else {
//             $result = false;
//         }
//         return $result;
// }

    
// function invalidUsername($userName){

//     if(!preg_match("/^[a-zA-Z0-9]*$/", $userName)){
//         $result = true;
//     }  else {
//         $result = false;
//     }
//     return $result;
// }

// function invalidEmail($email){

//     if (filter_var($email, FILTER_VALIDATE_EMAIL)){
//         $result = true; 
//     }
//     else {
//         $result = false;
//     }
//     return $result;

// }
 
// function pwdMatch($pwd, $pwdConfirm){

//     if ($pwd !== $pwdConfirm){
//         $result = true; 
//     }
//     else {
//         $result = false;
//     }
//     return $result;

// }
// function userNameExists($conn, $userName, $email){
//     $sql = "SELECT * FROM users WHERE usersId = ? OR usersEmail = ?";
//     $stmt = mysqli_stmt_init($conn);
//     if(!mysqli_stmt_prepare($stmt,$sql)){
//         header("location: signup.php?error=stmtfailed");
//         exit();
//     }

//     mysqli_stmt_bind_param($stmt, "ss", $userName, $email);

//     mysqli_stmt_execute($stmt);

//     $resultData = mysqli_stmt_get_result($stmt);

//     if($row = mysqli_fetch_assoc($resultData)){
//     return $row;
//     }
//     else{
//         $result = false;
//         return $result; 
//     }

//     mysqli_stmt_close($stmt);

// }



// function createUsers($conn, $userName, $email, $pwd){
//     $sql = "INSERT INTO users (usersName, usersEmail, usersPwd) VALUES (?,?,?)";
//     $stmt = mysqli_stmt_init($conn);
//     if(!mysqli_stmt_prepare($stmt,$sql)){
//         header("location: signup.php?error=stmtfailed");
//         exit();
//     }

//     $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

//     mysqli_stmt_bind_param($stmt, "sss", $userName, $email, $hashedPwd);
//     mysqli_stmt_execute($stmt);
//     mysqli_stmt_close($stmt);
//     header("location: signup.php?error=none");
//         exit();

// }



