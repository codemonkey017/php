<?php



if(isset($_POST["login__Submit"])){
    require "database.php";
    // $email = $_POST["email"];
    $pwd = $_POST["pwd"];
    $username = $_POST['userName'];

    if(empty($username) || empty($pwd)){
        header("Location:../index.php?error=emptyfields");
        exit();
    }
    else {
        //this code blocks only check if statement works with database
        $sql = "SELECT * FROM users WHERE usersName=? OR usersEmail=?; ";
        $stmt = mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("Location:../index.php?error=sqlerror");
            exit();   
        }
        else {
            //this code blocks check we got a result
            mysqli_stmt_bind_param($stmt, "ss", $username, $username);
            mysqli_stmt_execute($stmt);
            $results = mysqli_stmt_get_result($stmt);
            if($row = mysqli_fetch_assoc($results)){
              $pwdCheck = password_verify($pwd, $row["usersPwd"]);
              if($pwdCheck == false){
                header("Location:../index.php?error=wrongpwd");
                exit();
              }
              //in order to log a user in we use sessions
              //session is a global variable, so it passes information
              else if ($pwdCheck == true){
                session_start();
                $_SESSION["usersId"] = $row["usersId"];
                $_SESSION["usersName"] = $row["usersName"];
                header("Location:../index.php?login=success");
                exit();

          
            }
            else {
                header("Location:../index.php?error=wrongpwd");
                exit();
            }
        }
        else{
            header("Location:../index.php?error=nouser");
        }
    }
    
}
}

