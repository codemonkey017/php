
<?php

session_start();
?>

<style>
<?php include 'main.css';
include 'mediaqueries.css';

?>
</style>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <title>Food Trials</title>
</head>
<body>

    <!-- start of nav  -->
    <div class="nav">
        <div class="nav__left">
        <i class="bi bi-chat-dots"></i>
        <!-- <img class="logo"src="./img/logo.png" alt=""> -->
            <form action="index.php" method="GET">
               <a class="searchClose" href="">X</a>
                <input type="text" name="searchDB" class="searchInput" placeholder="search" >
                <!-- <button type="submit" name="searchSubmit" class="searchButton">Search</button> -->
            </form>
            <i class="bi bi-bell-fill nav__icon"></i>
        </div>
        <div class="nav__right">
               <button type="button" class="login__Button">Log In</button>
               <button type="button" class="signup__Button">Sign Up</button>
     </div>
    </div>
    <!-- end of nav  -->

    <!-- start of content section -->
   <section class="content__section">
    <div class="content__section--heading"><p>Trending Today</p></div>
   <div class="trending">
        <div><img class="img  grid__item--1" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
        <div><img class="img  grid__item--2" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
        <div><img class="img  grid__item--3" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
        <div><img class="img grid__item--4" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
    </div>
    <div class="content__section--heading"></div>
    <div class="signup__form">
        <form action="signup.php" method="POST">
        <label for="userName">Username</label>
        <input type="text" name="userName" placeholder="username">
        <label for="email">Email</label>
        <input type="email" name="email" placeholder="email">
        <label for="password">Password</label>
        <input type="password" name="pwd" placeholder="password">
        <label for="passwordConfrim">Password Confrim</label>
        <input type="password" name="pwdConfirm" placeholder="password">
        <button type="submit" class="signup__Submit" name="signup__Submit">Sign Up</button>
        </form>
        <a href="" class="signup__exit" style="display:flex; justify-content: center; margin-top:1rem;">Exit</a>
      </div>
      <div class="login__form">
        <form action="login.php" method="POST">
        <label for="userName">Username</label>
        <input type="text" name="userName" placeholder="username">
        <label for="password">Password</label>
        <input type="password" name="pwd" placeholder="password">
        <button type="submit" class="login__Submit" name="login__Submit">Login</button>
        </form>
        <a href="" class="login__exit" style="display:flex; justify-content: center; margin-top:1rem;">Exit</a>
      </div>
    </section>
    <!-- end of content -->
    


    <!-- start of post -->
    <section class="post">
        <div class="post__display">individual post threads goes here
        <p><?php if (!empty($_GET)){ echo $_GET["searchDB"];}?></p>
        </div>
    </section>
    <!-- end of post -->

  

  
  


    <script src="script.js"></script>
</body>
</html>