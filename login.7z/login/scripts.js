//search database
const searchButton = document.querySelector(".searchButton");
const searchInput = document.querySelector(".searchInput");
const searchClose  = document.querySelector(".searchClose");

searchInput.addEventListener("input", function(e) {
    console.log(searchInput.value);

    
    if(searchInput.value) {
        console.log("there is a log ");
        searchClose.style.display = "initial";
        e.preventDefault();
    }
})


searchClose.addEventListener("click", function(e){
    searchClose.style.display = "none";
    searchInput.value = "";
    e.preventDefault();
})

//signup display 

const signupButton = document.querySelector(".signup__Button");
const trending = document.querySelector(".trending");
const signupForm = document.querySelector(".signup__form");
const contentHeading = document.querySelector(".content__section--heading");
const signupExit = document.querySelector(".signup__exit");
const nav = document.querySelector(".nav");
let query = window.matchMedia("(max-width:400px)")


signupButton.addEventListener("click", function(){
 signupForm.style.display = "block";
 trending.style.display ="none";
 contentHeading.style.display ="none";
 searchInput.setAttribute("disabled", "true");
 loginButton.setAttribute("disabled", "true");

})
signupExit.addEventListener("click", function(e){
 signupForm.style.display = "none";
 trending.style.display ="grid";
 contentHeading.style.display ="block";
 searchInput.removeAttribute("disabled");
 loginButton.removeAttribute("disabled");

if(query.matches){
     navLeft.style.display = "flex";
     navRight.style.display = "none";
}
 e.preventDefault();

})

// login display

const loginButton = document.querySelector(".login__Button");
const loginForm = document.querySelector(".login__form");
const loginExit = document.querySelector(".login__exit");

loginButton.addEventListener("click", function(){
    loginForm.style.display = "block";
    trending.style.display ="none";
    contentHeading.style.display ="none";
    searchInput.setAttribute("disabled", "true");
    signupButton.setAttribute("disabled", "true");
   })

   loginExit.addEventListener("click", function(e){
    loginForm.style.display = "none";
    trending.style.display ="grid";
    contentHeading.style.display ="block";
    searchInput.removeAttribute("disabled");
    signupButton.removeAttribute("disabled");
    if(query.matches){
        navLeft.style.display = "flex";
        navRight.style.display = "none";
   }
    e.preventDefault();
   
   })

   //nav icon function 

   const navIcon = document.querySelector(".nav__icon");
   const navRight = document.querySelector(".nav__right");
   const navLeft = document.querySelector(".nav__left");
   const navIcon2 = document.querySelector(".nav__icon--2");

   
   navIcon.addEventListener("click", function(){
    navLeft.style.display = "none";
    navRight.style.display = "flex";
    alert("hello");
    
    // navRight.style.justifyContent = "center";


   
   })

   navIcon2.addEventListener("click", function(){
    alert("hello");
    console.log("click");
    

   
   })





