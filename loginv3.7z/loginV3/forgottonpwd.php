
<style>
    <?php
include "main.css";
include "mediaqueries.css";
?>
</style>

         <p class="forgot__p" style="display:flex; justify-content: center;">Reset Password</p>
        <div class="forgot__form">
        <form action="./include/forgottonpwd.php" method="POST">
        <input type="email" name="email" placeholder="email">
        <button type="submit" class="reset__Submit" name="reset__Submit">Reset Password</button>
        </form>

        <?php
         
         if(isset($_GET["reset"])){
            if(($_GET["reset"]  == "success")){
                echo "<p>Check Your Email</p>";
            }
         }


?>