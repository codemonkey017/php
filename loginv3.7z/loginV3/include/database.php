<?php


$serverName = "localhost";
$dbUsername = "u641319817_adminWo";
$dbPassword = "Wolf2pac!";
$dbName = "u641319817_hoodbios";

$conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);

if(!$conn){
    die("connection failed: " . mysqli_connect_error());

}
