<?php
require "header.php"
?>

<style>
    <?php
include "main.css";
include "mediaqueries.css";
?>
</style>



<main class="logged__mssg">
<?php 
if(isset($_SESSION["userId"])){
    echo "<p>You are logged in</p>";
} 
else {
    echo "<p>You are logged out</p>";
}


?>
</main>

    <!-- start of post -->
    <section class="post">
        <div class="post__display">individual post threads goes here
        <p><?php if (!empty($_GET)){ echo $_GET["searchDB"];}?></p>
        </div>
    </section>
    <!-- end of post -->


<?php
require "footer.php"
?>