

   const navIcon2 = document.querySelector(".nav__icon--2");
   const memberMenu = document.querySelector(".member__menu");
   const profileButton = document.querySelector(".profile__Button");
   const logoutLink = document.querySelector(".logout__Link");

   
   
      const menu = function () {
       memberMenu.style.display = "block";
      }

   navIcon2.addEventListener("click", menu);
//    profileButton.addEventListener("click", menu);
    

logoutLink.addEventListener("click", function(e){
    e.preventDefault();
    window.location.href = 'include/logout.php';
})
