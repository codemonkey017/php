<?php 


if(isset($_POST["resetPwd__Submit"])){
    $selector = $_POST["selector"];
    $validator = $_POST["validator"];
    $pwd = $_POST["pwd"];
    $pwdConfirm = $_POST["pwdConfirm"];

    if(empty($pwd) || empty($pwdConfirm)) {
        header("Location: ../forgotpwd.php");
        exit();
    } else if ($pwd != $pwdConfirm){
        header("Location: ../forgotpwd.php");
        exit();
    }

    $currentDate = date("U");
    require "database.php";
    $sql = "SELECT * FROM pwdReset WHERE pwdResetSelector=? and pwdResetExpires >=?";

    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt,$sql)){
        echo"There was an error! dope";
        exit(); 

    } else {
        mysqli_stmt_bind_param($stmt, "ss", $selector, $currentDate );
        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);
        if(!$row = mysqli_fetch_assoc($result)){
            echo "You need to resubmit your reset request"; 
            exit();
        } else {
            $tokenBin = hex2bin($validator);
            $tokenCheck = password_verify($tokenBin, $row["pwdResetToken"]);

            if ($tokenCheck === false){
                echo "You need to resubmit your reset request";
                exit();
            } 
            elseif ($tokenCheck === true){
                $tokenEmail = $row["pwdResetEmail"];

                $sql = "SELECT * FROM users WHERE usersEmail=?;";
                $stmt = mysqli_stmt_init($conn);
                if(!mysqli_stmt_prepare($stmt,$sql)){
                    echo "There was an Error! noioioio";
                    exit();
                }
                else {
                    mysqli_stmt_bind_param($stmt, "s", $tokenEmail);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    if(!$row = mysqli_fetch_assoc($result)){
                        echo "There was an error hello"; 
                        exit();

                    }

                    else {
                        $sql = "UPDATE users SET usersPwd=? WHERE usersEmail=?";
                        $stmt = mysqli_stmt_init($conn);
                        if(!mysqli_stmt_prepare($stmt,$sql)){
                            echo"There was an error! yes";
                            exit(); 
                    
                        } else {
                            $newPwdHash = password_hash($pwd, PASSWORD_DEFAULT);
                            mysqli_stmt_bind_param($stmt, "ss", $newPwdHash, $tokenEmail);
                            mysqli_stmt_execute($stmt);

                            $sql = "DELETE FROM pwdreset WHERE pwdResetEmail=?";
                            $stmt = mysqli_stmt_init($conn);
                            if(!mysqli_stmt_prepare($stmt,$sql)){
                                echo"There was an error! oops";
                                exit(); 
                        
                            } else {
                                mysqli_stmt_bind_param($stmt, "s", $tokenEmail);
                                mysqli_stmt_execute($stmt);
                                header("Location:../index.php");
                            }
                        }
                    }

                }
            }
        }
        
        
    }
    
  

}