
<?php

if(isset($_POST["login__Submit"])){
    require "database.php";
    $usernameLogin = $_POST["usernameLogin"];
    $password = $_POST["pwdLogin"];

    if(empty($usernameLogin) || empty($password)){
        header("Location:../index.php?error=emptyfields");
        exit();
    }
    else {
        $sql = "SELECT * FROM users WHERE usersName=? OR usersEmail=?; ";
        $stmt = mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("Location:../index.php?error=sqlerror");
            exit();   
        }
        else {
            mysqli_stmt_bind_param($stmt, "ss", $usernameLogin, $usernameLogin);
            mysqli_stmt_execute($stmt);
            $results = mysqli_stmt_get_result($stmt);
            if($row = mysqli_fetch_assoc($results)){
              $pwdCheck = password_verify($password, $row["usersPwd"]);
              if($pwdCheck == false){
                header("Location:../index.php?error=wrongpwd");
                exit();
              }
              else if ($pwdCheck == true){
                session_start();
                $_SESSION["userId"] = $row["usersId"];
                $_SESSION["userName"] = $row["usersName"];
                header("Location:../index.php");
           

          
            }
            else {
                header("Location:../index.php?error=wrongpwd");
                exit();
            }
        }
        else{
            header("Location:../index.php?error=nouser");
        }
    }
    
}
}



