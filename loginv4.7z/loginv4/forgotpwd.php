
<style>
    <?php
include "main.css";
include "mediaqueries.css";
?>
</style>


<?php
     
     //getting data user click from email link 
      $selector = $_GET["selector"];
      $validator = $_GET["validator"];

      if(empty($selector) || empty($validator)){
        echo "Could not validate your request";
      } else {
        if (ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false ){

          echo '
          
              <form action="./include/pwdreset.php" method="post">
              <input type="hidden" name="selector" value="<?php echo $selector ?>">
              <input type="hidden" name="validator" value="<?php echo $validator ?>">
              <input type="password" name="pwd" placeholder="enter password">
              <input type="password" name="pwdConfirm" placeholder="confirm password">
              <button type="submit" name="resetPwd__Submit"></button>
          ';

        }
      }
       


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>





</form>
</body>
</html>