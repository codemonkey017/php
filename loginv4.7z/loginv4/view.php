<?php
require "header.php";
?>

<style>
    <?php
include "main.css";
include "mediaqueries.css";
?>
</style>

<main class="logged__mssg">
<?php 
if(!isset($_SESSION["userId"])){
    echo '
    
    <body>
<!-- start of nav  -->
   <div class="nav">
        <div class="nav__left">
        <i class="bi bi-chat-dots"></i>
        <!-- <img class="logo"src="./img/logo.png" alt=""> -->
            <form action="index.php" method="GET">
               <a class="searchClose" href="">X</a>
                <input type="text" name="searchDB" class="searchInput" placeholder="search" >
                <!-- <button type="submit" name="searchSubmit" class="searchButton">Search</button> -->
            </form>
            <i class="bi bi-bell-fill nav__icon"></i>
        </div>
            <div class="nav__right">
            <button type="button" class="login__Button">Log In</button>
            <button type="button" class="signup__Button">Sign Up</button>
            </div>
    </div>
    <!-- end of nav  -->

    <!-- start of content section -->
   <section class="content__section">
    <div class="content__section--heading"><p>Trending Today</p></div>
   <div class="trending">
        <div><img class="img  grid__item--1" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
        <div><img class="img  grid__item--2" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
        <div><img class="img  grid__item--3" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
        <div><img class="img grid__item--4" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
    </div>
    <div class="content__section--heading"></div>
    <div class="signup__form">
        <form action="./include/signup.php" method="POST">
        <label for="userName">Username</label>
        <input type="text" name="username" placeholder="username">
        <label for="email">Email</label>
        <input type="email" name="email" placeholder="email">
        <label for="password">Password</label>
        <input type="password" name="pwd" placeholder="password">
        <label for="passwordConfrim">Password Confrim</label>
        <input type="password" name="pwdConfirm" placeholder="password">
        <button type="submit" class="signup__Submit" name="signup__Submit">Sign Up</button>
        </form>
        <a href="" class="signup__exit" style="display:flex; justify-content: center; margin-top:1rem;">Exit</a>
      </div>
      <div class="login__form">
        <form action="./include/login.php" method="POST">
        <label for="username">Username</label>
        <input type="text" name="usernameLogin" placeholder="username">
        <label for="password">Password</label>
        <input type="password" name="pwdLogin" placeholder="password">
        <button type="submit" class="login__Submit" name="login__Submit">Login</button>
        </form>
        <a href="" class="login__exit" style="display:flex; justify-content: center; margin-top:1rem;">Exit</a>
      </div>
    </section>
    <!-- end of content -->

    <script src="scripts.js"></script>
</body>
    ';
} 
?>

<?php 
if(isset($_SESSION["userName"])){
    echo 
 '<body>          
    <!-- start of nav  -->
    <div class="member__menu">
    <ul>
    <li><a href="">Profile</a></li>
    <li ><a class="logout__Link" href="">Logout</a></li>
</ul>
    
    </div>
<div class="nav">
<div class="nav__left">
<i class="bi bi-chat-dots"></i>
<!-- <img class="logo"src="./img/logo.png" alt=""> -->
    <form action="index.php" method="GET">
       <a class="searchClose" href="">X</a>
        <input type="text" name="searchDB" class="searchInput" placeholder="search" >
        <!-- <button type="submit" name="searchSubmit" class="searchButton">Search</button> -->
    </form>
    <i class="bi bi-bell-fill nav__icon--2"></i>
</div>
    <div class="nav__right">
    <form action="./include/logout.php">
    <button type="submit" class="logout__Button">Log Out</button>
   </form>
    <button type="button" class="Profile__Button">Profile</button>
</div>
</div>
<!-- end of nav  -->

<!-- start of content section -->
<section class="content__section">
<div class="content__section--heading"><p>Trending Today</p></div>
<div class="trending">
<div><img class="img  grid__item--1" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
<div><img class="img  grid__item--2" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
<div><img class="img  grid__item--3" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
<div><img class="img grid__item--4" src="https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI" alt=""></div>
</div>
<div class="content__section--heading"></div>
<div class="signup__form">
<form action="./include/signup.php" method="POST">
<label for="userName">Username</label>
<input type="text" name="username" placeholder="username">
<label for="email">Email</label>
<input type="email" name="email" placeholder="email">
<label for="password">Password</label>
<input type="password" name="pwd" placeholder="password">
<label for="passwordConfrim">Password Confrim</label>
<input type="password" name="pwdConfirm" placeholder="password">
<button type="submit" class="signup__Submit" name="signup__Submit">Sign Up</button>
</form>
<a href="" class="signup__exit" style="display:flex; justify-content: center; margin-top:1rem;">Exit</a>
</div>
<div class="login__form">
<form action="./include/login.php" method="POST">
<label for="username">Username</label>
<input type="text" name="usernameLogin" placeholder="username">
<label for="password">Password</label>
<input type="password" name="pwdLogin" placeholder="password">
<button type="submit" class="login__Submit" name="login__Submit">Login</button>
</form>
<a href="" class="login__exit" style="display:flex; justify-content: center; margin-top:1rem;">Exit</a>
</div>
</section>
<!-- end of content -->
<script src="scripts2.js"></script>
</body>';
}?>

<?php 
if(isset($_SESSION["userId"])){
    require "include/database.php";


    if(isset($_POST["post__Submit"])){
       
        

        $title = $_POST["title"];
        $content = $_POST["content"];
        date_default_timezone_set('America/Los_Angeles');
        $date = date("F j, Y, g:i a");
        $name = $_SESSION["userName"];
        
        
        
            //create a template 
        $sql = "INSERT INTO posts (postTitle, postContent, postDate, postUser) VALUES (?, ?, ?, ?);"; 
        //create a prepare statement 
        $stmt = mysqli_stmt_init($conn);
        //prepare the prepare the statement 
        if(!mysqli_stmt_prepare($stmt, $sql)){
            echo "SQL statement failed";
        } else {
            //bind parameters to the placeholder
            mysqli_stmt_bind_param($stmt, "ssss", $title, $content, $date, $name);
            //run parameters inside database
            mysqli_stmt_execute($stmt);
        }
        }
}

?>



<?php

$topic = $_GET['topic'];

if(!isset($_SESSION["userId"])){
echo "you are not logged";
} else {
    echo "you are logged";
}

?>

<?php
    $sql = "SELECT * FROM posts WHERE id = ?;";
            //create a prepare statement 
            $stmt = mysqli_stmt_init($conn);
            //prepare the prepare the statement 
            if(!mysqli_stmt_prepare($stmt, $sql)){
                echo "SQL statement failed";
            } else {
                //bind parameters to the placeholder
                mysqli_stmt_bind_param($stmt, "s", $topic);
                //run parameters inside database
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);

                while ($row = mysqli_fetch_assoc($result)){
                    echo "

                    <section class='post--2'>
                    <div class='post__display--2'>
                        <div class='thread__display'>
                        <h4>{$row['postTitle']} posted by <span style='font-size:.7rem; color: black;'>{$row['postUser']}</span></h4>
                        <p style='margin-top:1rem;'>{$row['postContent']}</p>
                        <iframe width='560' height='315' src='https://www.youtube.com/embed/{$value}'></iframe>
                        
                        </div>
                    </div>
                    </section>

                    ";
            
                }

            }
    
    
    ?>






<?php 


